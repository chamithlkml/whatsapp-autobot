create definer = root@localhost view logs as
select `resthous_resthousedb`.`whatsapp_logs`.`id`      AS `id`,
       `resthous_resthousedb`.`whatsapp_logs`.`message` AS `message`
from `resthous_resthousedb`.`whatsapp_logs`;

